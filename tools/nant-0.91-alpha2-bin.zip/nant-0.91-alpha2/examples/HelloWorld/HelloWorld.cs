public class ProjectName {
    static void Main() {
        System.Console.WriteLine("Hello World using C#");
    }
}
